import './style.css';
import App from './components/app';

export default App;
